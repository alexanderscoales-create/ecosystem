# ARES agent movement pass

This is the first additive agent-simulation milestone for the existing `claude/ares-habitat-gui-jjlxp9` branch.

## What it adds

- A dedicated physical Habitat route graph (`src/data/worldRoutes.ts`) separate from `handsOffTo`.
- Dijkstra route selection over percentage-space waypoints.
- One cinematic field unit that travels Bridge → Commerce Lab → Content Engine → Media Bay and repeats.
- Walking/working animation, facing direction, glowing route lines, destination aura, hover/focus mission tooltip.
- Reduced-motion support: the unit stops instead of continuously travelling.

## Apply

1. Copy `src/data/worldRoutes.ts` into the repo.
2. Copy `src/components/AgentLayer.tsx` into the repo.
3. Replace `src/components/HubView.tsx` with `HubView.tsx.replacement`.
4. Replace `src/App.tsx` with `App.tsx.replacement`.
5. Append `src/styles/agent-layer.css` to the end of `src/styles/app.css`.
6. Run `npm run build`.

The temporary CSS humanoid is intentionally a stand-in for the Pixel Lab sprite sheet. The movement system is independent of the renderer, so the next pass can swap only the visual body for character art while keeping the route/runtime logic intact.
