import type { RoomId } from '../types';

export interface WorldNode {
  id: string;
  x: number;
  y: number;
  roomId?: RoomId;
}

interface WorldEdge {
  a: string;
  b: string;
}

/**
 * Physical traversal graph for the Habitat. This is deliberately separate from
 * Room.handsOffTo, which describes logical workflow handoffs rather than roads.
 * Coordinates are in the same 0-100 image percentage space as hubAnchor.
 */
export const WORLD_NODES: WorldNode[] = [
  { id: 'bridge', x: 50, y: 24.5, roomId: 'bridge' },
  { id: 'tower-mid', x: 50, y: 43 },
  { id: 'tower-step', x: 50, y: 58 },
  { id: 'commerce-lab', x: 50, y: 76, roomId: 'commerce-lab' },
  { id: 'lower-west', x: 38, y: 79 },
  { id: 'archive-cross', x: 27, y: 78 },
  { id: 'content-engine', x: 15, y: 67, roomId: 'content-engine' },
  { id: 'west-rise', x: 15.5, y: 56 },
  { id: 'media-bay', x: 20.5, y: 45, roomId: 'media-bay' },
  { id: 'north-west', x: 34, y: 35 },
  { id: 'research-lab', x: 76, y: 44, roomId: 'research-lab' },
  { id: 'east-mid', x: 68, y: 58 },
  { id: 'radar-bay', x: 69.5, y: 84, roomId: 'radar-bay' },
  { id: 'treasury', x: 88, y: 66, roomId: 'treasury' },
  { id: 'archives', x: 24, y: 87, roomId: 'archives' },
];

export const WORLD_EDGES: WorldEdge[] = [
  { a: 'bridge', b: 'tower-mid' },
  { a: 'tower-mid', b: 'tower-step' },
  { a: 'tower-step', b: 'commerce-lab' },
  { a: 'tower-step', b: 'east-mid' },
  { a: 'tower-mid', b: 'north-west' },
  { a: 'north-west', b: 'media-bay' },
  { a: 'media-bay', b: 'west-rise' },
  { a: 'west-rise', b: 'content-engine' },
  { a: 'content-engine', b: 'archive-cross' },
  { a: 'archive-cross', b: 'lower-west' },
  { a: 'lower-west', b: 'commerce-lab' },
  { a: 'archive-cross', b: 'archives' },
  { a: 'east-mid', b: 'research-lab' },
  { a: 'east-mid', b: 'radar-bay' },
  { a: 'east-mid', b: 'treasury' },
  { a: 'radar-bay', b: 'treasury' },
];

const nodeById = new Map(WORLD_NODES.map((node) => [node.id, node]));
const neighbors = new Map<string, string[]>();
for (const edge of WORLD_EDGES) {
  neighbors.set(edge.a, [...(neighbors.get(edge.a) ?? []), edge.b]);
  neighbors.set(edge.b, [...(neighbors.get(edge.b) ?? []), edge.a]);
}

function distance(a: WorldNode, b: WorldNode) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** Small Dijkstra implementation so route choice remains data-driven. */
export function shortestWorldPath(from: string, to: string): WorldNode[] {
  const distances = new Map<string, number>([[from, 0]]);
  const previous = new Map<string, string>();
  const unvisited = new Set(WORLD_NODES.map((node) => node.id));

  while (unvisited.size > 0) {
    let current: string | null = null;
    let best = Number.POSITIVE_INFINITY;
    for (const id of unvisited) {
      const d = distances.get(id) ?? Number.POSITIVE_INFINITY;
      if (d < best) {
        best = d;
        current = id;
      }
    }

    if (!current || current === to) break;
    unvisited.delete(current);
    const currentNode = nodeById.get(current)!;

    for (const next of neighbors.get(current) ?? []) {
      if (!unvisited.has(next)) continue;
      const nextNode = nodeById.get(next)!;
      const candidate = best + distance(currentNode, nextNode);
      if (candidate < (distances.get(next) ?? Number.POSITIVE_INFINITY)) {
        distances.set(next, candidate);
        previous.set(next, current);
      }
    }
  }

  const ids = [to];
  while (ids[0] !== from) {
    const prev = previous.get(ids[0]);
    if (!prev) return [nodeById.get(from)!, nodeById.get(to)!];
    ids.unshift(prev);
  }
  return ids.map((id) => nodeById.get(id)!);
}

export const DEMO_STOPS: RoomId[] = ['bridge', 'commerce-lab', 'content-engine', 'media-bay'];
