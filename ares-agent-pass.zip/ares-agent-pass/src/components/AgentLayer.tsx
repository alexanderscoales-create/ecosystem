import { useEffect, useMemo, useRef, useState } from 'react';
import { DEMO_STOPS, shortestWorldPath, WORLD_EDGES, WORLD_NODES, type WorldNode } from '../data/worldRoutes';
import { roomById } from '../data/rooms';
import type { RoomId } from '../types';

interface Props {
  motionEnabled: boolean;
}

interface AgentPose {
  x: number;
  y: number;
  facing: 1 | -1;
  moving: boolean;
  from: RoomId;
  to: RoomId;
  progress: number;
}

const SPEED = 7.2; // percentage-space units / second
const DWELL_MS = 1800;

function nodeDistance(a: WorldNode, b: WorldNode) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

export default function AgentLayer({ motionEnabled }: Props) {
  const [pose, setPose] = useState<AgentPose>({
    x: 50,
    y: 24.5,
    facing: 1,
    moving: false,
    from: 'bridge',
    to: 'commerce-lab',
    progress: 0,
  });
  const stopIndex = useRef(0);
  const cancelled = useRef(false);

  const routeLines = useMemo(() => {
    const byId = new Map(WORLD_NODES.map((node) => [node.id, node]));
    return WORLD_EDGES.map((edge) => ({ a: byId.get(edge.a)!, b: byId.get(edge.b)! }));
  }, []);

  useEffect(() => {
    cancelled.current = false;
    if (!motionEnabled) {
      setPose((p) => ({ ...p, moving: false }));
      return () => {
        cancelled.current = true;
      };
    }

    let frame = 0;
    let dwellTimer = 0;

    const travel = () => {
      const from = DEMO_STOPS[stopIndex.current];
      const nextIndex = (stopIndex.current + 1) % DEMO_STOPS.length;
      const to = DEMO_STOPS[nextIndex];
      const path = shortestWorldPath(from, to);
      let segment = 0;
      let journeyDone = 0;
      const journeyLength = path.slice(1).reduce((sum, node, i) => sum + nodeDistance(path[i], node), 0);

      const runSegment = () => {
        const a = path[segment];
        const b = path[segment + 1];
        if (!a || !b) {
          stopIndex.current = nextIndex;
          setPose((p) => ({ ...p, x: path.at(-1)!.x, y: path.at(-1)!.y, moving: false, progress: 1 }));
          dwellTimer = window.setTimeout(() => !cancelled.current && travel(), DWELL_MS);
          return;
        }

        const length = nodeDistance(a, b);
        const duration = Math.max(650, (length / SPEED) * 1000);
        const started = performance.now();
        const facing: 1 | -1 = b.x >= a.x ? 1 : -1;

        const tick = (now: number) => {
          if (cancelled.current) return;
          const t = Math.min(1, (now - started) / duration);
          const eased = t * t * (3 - 2 * t);
          setPose({
            x: a.x + (b.x - a.x) * eased,
            y: a.y + (b.y - a.y) * eased,
            facing,
            moving: true,
            from,
            to,
            progress: Math.min(1, (journeyDone + length * t) / journeyLength),
          });
          if (t < 1) {
            frame = requestAnimationFrame(tick);
          } else {
            journeyDone += length;
            segment += 1;
            runSegment();
          }
        };
        frame = requestAnimationFrame(tick);
      };
      runSegment();
    };

    dwellTimer = window.setTimeout(travel, 900);
    return () => {
      cancelled.current = true;
      cancelAnimationFrame(frame);
      window.clearTimeout(dwellTimer);
    };
  }, [motionEnabled]);

  const destination = roomById(pose.to);
  const mission = pose.moving ? `En route to ${destination.name}` : `Working at ${roomById(DEMO_STOPS[stopIndex.current]).name}`;

  return (
    <div className="agent-layer">
      <svg className="agent-routes" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <defs>
          <filter id="route-glow" x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="0.42" result="blur" />
            <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        {routeLines.map(({ a, b }) => (
          <line key={`${a.id}-${b.id}`} x1={a.x} y1={a.y} x2={b.x} y2={b.y} className="agent-route" />
        ))}
      </svg>

      <div className="agent-destination" style={{ left: `${pose.x}%`, top: `${pose.y}%` }} aria-hidden="true" />

      <div
        className={`agent-unit${pose.moving ? ' is-moving' : ' is-working'}`}
        style={{
          left: `${pose.x}%`,
          top: `${pose.y}%`,
          ['--agent-facing' as string]: pose.facing,
        }}
        tabIndex={0}
        aria-label={`JARVIS field unit. ${mission}. ${Math.round(pose.progress * 100)} percent complete.`}
      >
        <span className="agent-unit__shadow" aria-hidden="true" />
        <span className="agent-unit__body" aria-hidden="true">
          <span className="agent-unit__head" />
          <span className="agent-unit__visor" />
          <span className="agent-unit__torso" />
          <span className="agent-unit__arm agent-unit__arm--left" />
          <span className="agent-unit__arm agent-unit__arm--right" />
          <span className="agent-unit__leg agent-unit__leg--left" />
          <span className="agent-unit__leg agent-unit__leg--right" />
          <span className="agent-unit__reactor" />
        </span>
        <span className="agent-tooltip">
          <strong>JARVIS // FIELD UNIT</strong>
          <span>{mission}</span>
          <span>{Math.round(pose.progress * 100)}% · {destination.agent.role}</span>
        </span>
      </div>
    </div>
  );
}
